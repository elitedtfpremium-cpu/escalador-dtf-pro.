import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

const $=id=>document.getElementById(id);let srcImg=null,srcName='diseno',resultBlob=null,resultUrl='',sourceUrl='',session=null,sessionKey='',cancel=false;
const MODEL_REPO='https://huggingface.co/othytenk/realesrgan-x4plus/resolve/main/';
const MAX_SIDE=16384,MAX_PIXELS=100000000;
function log(s){$('log').textContent=s}function progress(p){$('pb').style.width=(p*100).toFixed(1)+'%'}function tick(){return new Promise(r=>setTimeout(r,0))}
function setRange(id,out,suffix=''){ $(id).addEventListener('input',()=>$(out).textContent=$(id).value+suffix)}setRange('blend','blendVal','%');setRange('sharp','sharpVal');setRange('grain','grainVal');
const profiles={logo:{blend:85,sharp:10,grain:0},illustration:{blend:90,sharp:10,grain:1},tpu:{blend:80,sharp:5,grain:0},photo:{blend:100,sharp:15,grain:1}};
$('profile').addEventListener('change',()=>{const p=profiles[$('profile').value];if(!p)return;for(const [id,val,out,suffix] of [['blend',p.blend,'blendVal','%'],['sharp',p.sharp,'sharpVal',''],['grain',p.grain,'grainVal','']]){$(id).value=val;$(out).textContent=val+suffix}log('Perfil aplicado. Puedes afinar los controles antes de escalar.')});
function currentDpi(){const v=$('dpi').value==='_only'?parseInt($('customDpi').value,10):parseInt($('dpi').value,10);return Number.isFinite(v)?v:300}
function updateTargetHeight(){if(!srcImg||!$('lockRatio').checked)return;const w=parseFloat($('targetW').value);if(Number.isFinite(w)&&w>0)$('targetH').value=(w*srcImg.naturalHeight/srcImg.naturalWidth).toFixed(2)}
$('targetW').addEventListener('input',updateTargetHeight);
$('lockRatio').addEventListener('change',()=>{if($('lockRatio').checked){updateTargetHeight();$('targetH').readOnly=true;$('targetH').style.opacity='.7'}else{$('targetH').readOnly=false;$('targetH').style.opacity='1'}});
$('targetH').readOnly=true;$('targetH').style.opacity='.7';

$('img').onchange=e=>{const f=e.target.files?.[0];if(!f)return;if(sourceUrl)URL.revokeObjectURL(sourceUrl);sourceUrl=URL.createObjectURL(f);srcName=f.name.replace(/\.[^.]+$/,'')||'diseno';const im=new Image();im.onload=()=>{srcImg=im;updateTargetHeight();$('originalPane').innerHTML='';const v=new Image();v.src=sourceUrl;$('originalPane').appendChild(v);$('stats').textContent=`Original: ${im.naturalWidth} × ${im.naturalHeight} px`;log(`Imagen cargada: ${im.naturalWidth} × ${im.naturalHeight} px. Salida 4x: ${im.naturalWidth*4} × ${im.naturalHeight*4} px.`)};im.onerror=()=>log('No se pudo leer la imagen.');im.src=sourceUrl};
function classic4x(img){const w=img.naturalWidth,h=img.naturalHeight,c=document.createElement('canvas');c.width=w*4;c.height=h*4;const x=c.getContext('2d');x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';x.drawImage(img,0,0,w*4,h*4);return c}
function resizeToPrintSize(source,w,h){if(source.width===w&&source.height===h)return source;const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d',{alpha:true});x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';x.clearRect(0,0,w,h);x.drawImage(source,0,0,w,h);return c}
function srcImgToCanvas(img){const c=document.createElement('canvas');c.width=img.naturalWidth;c.height=img.naturalHeight;const x=c.getContext('2d',{alpha:true});x.drawImage(img,0,0);return c}

function openModelDB(){
 return new Promise((resolve,reject)=>{
  if(!('indexedDB' in window))return reject(Error('IndexedDB no está disponible'));
  const req=indexedDB.open('dtf-pro-model-cache',1);
  req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('models'))req.result.createObjectStore('models')};
  req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||Error('No se pudo abrir la caché local'));
 });
}
async function readCachedModel(key){
 let db;try{db=await openModelDB();return await new Promise((resolve,reject)=>{
  const tx=db.transaction('models','readonly'),req=tx.objectStore('models').get(key);
  req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error);
 });}finally{if(db)db.close();}
}
async function saveCachedModel(key,buffer){
 let db;try{db=await openModelDB();await new Promise((resolve,reject)=>{
  const tx=db.transaction('models','readwrite');tx.objectStore('models').put(buffer,key);
  tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('No se pudo guardar el modelo'));
 });}finally{if(db)db.close();}
}
async function downloadModel(url,key){
 let buffer=await readCachedModel(key);
 if(buffer){$('modelStatus').textContent='Modelo guardado en este navegador';log('Modelo IA encontrado en la caché local. Preparando motor…');return new Uint8Array(buffer);}
 log('Descargando modelo IA automáticamente. La primera descarga puede tardar…');
 $('modelStatus').textContent='Descargando modelo IA…';
 const response=await fetch(url,{mode:'cors',cache:'force-cache'});
 if(!response.ok)throw Error('No se pudo descargar el modelo IA (HTTP '+response.status+'). Comprueba tu conexión.');
 const total=Number(response.headers.get('content-length'))||0;
 if(!response.body){buffer=await response.arrayBuffer();}
 else{
  const reader=response.body.getReader(),chunks=[];let received=0;
  while(true){
   const part=await reader.read();if(part.done)break;
   chunks.push(part.value);received+=part.value.length;
   if(total){const pct=Math.min(99,received/total*100);progress(pct/100);log('Descargando modelo IA… '+pct.toFixed(0)+'% ('+(received/1048576).toFixed(1)+' / '+(total/1048576).toFixed(1)+' MB)');}
   else log('Descargando modelo IA… '+(received/1048576).toFixed(1)+' MB');
  }
  const joined=new Uint8Array(received);let offset=0;for(const c of chunks){joined.set(c,offset);offset+=c.length;}buffer=joined.buffer;
 }
 try{await saveCachedModel(key,buffer);$('modelStatus').textContent='Modelo descargado y guardado';}
 catch(e){$('modelStatus').textContent='Modelo descargado · caché no disponible';}
 return new Uint8Array(buffer);
}
async function loadModel(){
 if(session)return session;
 if(!window.ort)throw Error('No se pudo cargar ONNX Runtime. Comprueba tu conexión a internet y vuelve a abrir el HTML.');
 let useFp16=false;
 if(navigator.gpu){
  try{const adapter=await navigator.gpu.requestAdapter();useFp16=!!(adapter&&adapter.features&&adapter.features.has('shader-f16'));}
  catch(e){}
 }
 const file=useFp16?'realesrgan_x4plus_fp16.onnx':'realesrgan_x4plus.onnx';
 const key='realesrgan-x4plus-'+(useFp16?'fp16':'fp32')+'-v1';
 const url=MODEL_REPO+file;
 const bytes=await downloadModel(url,key);
 let err;
 for(const ep of [['webgpu'],['wasm']]){
  try{
   log('Inicializando Real-ESRGAN con '+(ep[0]==='webgpu'?'GPU WebGPU':'CPU/WebAssembly')+'…');
   session=await ort.InferenceSession.create(bytes,{executionProviders:ep,graphOptimizationLevel:'all'});
   sessionKey=key;$('modelStatus').textContent='IA lista · '+(ep[0]==='webgpu'?'GPU':'CPU');
   return session;
  }catch(e){err=e;}
 }
 throw err||Error('No se pudo iniciar el modelo IA en este navegador.');
}
function sampleRGBA(data,W,H,x,y){x=Math.max(0,Math.min(W-1,x));y=Math.max(0,Math.min(H-1,y));return ((y*W+x)*4)}
async function aiUpscaleToTarget(img,sess,T,targetW,targetH){
 const W=img.naturalWidth,H=img.naturalHeight;
 const sc=document.createElement('canvas');sc.width=W;sc.height=H;
 const sctx=sc.getContext('2d',{willReadFrequently:true});sctx.drawImage(img,0,0);
 const src=sctx.getImageData(0,0,W,H).data;
 const out=document.createElement('canvas');out.width=targetW;out.height=targetH;
 const ox=out.getContext('2d',{alpha:true});
 ox.imageSmoothingEnabled=true;ox.imageSmoothingQuality='high';
 const inputName=sess.inputNames[0],outputName=sess.outputNames[0],P=16;
 const nx=Math.ceil(W/T),ny=Math.ceil(H/T),total=nx*ny;let done=0;
 for(let ty=0;ty<H;ty+=T){
  for(let tx=0;tx<W;tx+=T){
   if(cancel)throw Error('Proceso cancelado');
   const tw=Math.min(T,W-tx),th=Math.min(T,H-ty);
   const x0=Math.max(0,tx-P),y0=Math.max(0,ty-P),x1=Math.min(W,tx+tw+P),y1=Math.min(H,ty+th+P);
   const cw=x1-x0,ch=y1-y0,plane=cw*ch,data=new Float32Array(3*plane);
   for(let y=0;y<ch;y++)for(let x=0;x<cw;x++){
    const si=((y0+y)*W+x0+x)*4,di=y*cw+x,a=src[si+3]/255;
    data[di]=(src[si]*a)/255;data[plane+di]=(src[si+1]*a)/255;data[2*plane+di]=(src[si+2]*a)/255;
   }
   let r;
   try{r=await sess.run({[inputName]:new ort.Tensor('float32',data,[1,3,ch,cw])})}
   catch(e){throw Error('El modelo rechazó un bloque de '+cw+'×'+ch+' px. Prueba un bloque menor. Detalle: '+(e.message||e))}
   const tensor=r[outputName],o=tensor.data,shape=tensor.dims;
   if(shape.length!==4)throw Error('Salida ONNX no compatible: se esperaba un tensor de 4 dimensiones.');
   const isNCHW=shape[1]===3||shape[1]===4,ow=isNCHW?shape[3]:shape[2],oh=isNCHW?shape[2]:shape[1],channels=isNCHW?shape[1]:shape[3];
   if(channels<3)throw Error('El modelo no devuelve al menos 3 canales RGB.');
   if(ow!==cw*4||oh!==ch*4)throw Error('El modelo no está entregando salida 4x. Comprueba que sea Real-ESRGAN x4.');
   const scale=Math.max(...Array.from(o.slice(0,Math.min(1000,o.length)),v=>Math.abs(v)))<=1.5?255:1;
   const coreX=(tx-x0)*4,coreY=(ty-y0)*4,coreW=tw*4,coreH=th*4;
   const tile=document.createElement('canvas');tile.width=coreW;tile.height=coreH;
   const tctx=tile.getContext('2d'),im=tctx.createImageData(coreW,coreH),td=im.data;
   for(let yy=0;yy<coreH;yy++)for(let xx=0;xx<coreW;xx++){
    const si=isNCHW?((coreY+yy)*ow+(coreX+xx)):((coreY+yy)*ow+(coreX+xx))*channels;
    const di=(yy*coreW+xx)*4;
    td[di]=Math.max(0,Math.min(255,o[si]*scale));
    td[di+1]=Math.max(0,Math.min(255,(isNCHW?o[ow*oh+si]:o[si+1])*scale));
    td[di+2]=Math.max(0,Math.min(255,(isNCHW?o[2*ow*oh+si]:o[si+2])*scale));
    td[di+3]=255;
   }
   tctx.putImageData(im,0,0);
   const dx=Math.round(tx/W*targetW),dy=Math.round(ty/H*targetH);
   const dx2=Math.round((tx+tw)/W*targetW),dy2=Math.round((ty+th)/H*targetH);
   ox.drawImage(tile,dx,dy,dx2-dx,dy2-dy);
   done++;progress(done/total);log(`IA adaptativa: bloque ${done}/${total} · salida final ${targetW}×${targetH} px · ${Math.round(done/total*100)}%`);
   await tick();
  }
 }
 // Mezcla opcional con la interpolación clásica, directamente a la resolución final.
 const amount=parseInt($('blend').value,10)/100;
 if(amount<1){
  const cl=document.createElement('canvas');cl.width=targetW;cl.height=targetH;
  const cx=cl.getContext('2d');cx.imageSmoothingEnabled=true;cx.imageSmoothingQuality='high';cx.drawImage(img,0,0,targetW,targetH);
  ox.globalAlpha=1-amount;ox.drawImage(cl,0,0);ox.globalAlpha=1;
 }
 // Reaplicar canal alfa original a la resolución final.
 const alpha=document.createElement('canvas');alpha.width=targetW;alpha.height=targetH;
 const ax=alpha.getContext('2d');ax.imageSmoothingEnabled=true;ax.imageSmoothingQuality='high';ax.drawImage(img,0,0,targetW,targetH);
 ox.globalCompositeOperation='destination-in';ox.drawImage(alpha,0,0);ox.globalCompositeOperation='source-over';
 return out;
}
function blendClassic(ai,img,amount){if(amount>=1)return ai;const cl=classic4x(img),a=ai.getContext('2d',{willReadFrequently:true}),b=cl.getContext('2d',{willReadFrequently:true}),A=a.getImageData(0,0,ai.width,ai.height),B=b.getImageData(0,0,ai.width,ai.height),d=A.data,e=B.data;for(let i=0;i<d.length;i+=4){d[i]=d[i]*amount+e[i]*(1-amount);d[i+1]=d[i+1]*amount+e[i+1]*(1-amount);d[i+2]=d[i+2]*amount+e[i+2]*(1-amount)}a.putImageData(A,0,0);return ai}
function finishTexture(canvas,sharp,grain){if(!sharp&&!grain)return canvas;const ctx=canvas.getContext('2d',{willReadFrequently:true}),im=ctx.getImageData(0,0,canvas.width,canvas.height),d=im.data,W=canvas.width,H=canvas.height;if(sharp>0){const blur=document.createElement('canvas');blur.width=W;blur.height=H;const bx=blur.getContext('2d');bx.filter='blur(1px)';bx.drawImage(canvas,0,0);bx.filter='none';const bd=bx.getImageData(0,0,W,H).data,k=sharp/100*.8;for(let i=0;i<d.length;i+=4){if(d[i+3]===0)continue;for(let c=0;c<3;c++)d[i+c]=Math.max(0,Math.min(255,d[i+c]+(d[i+c]-bd[i+c])*k))}}if(grain>0){for(let i=0;i<d.length;i+=4){if(d[i+3]===0)continue;const n=(Math.random()+Math.random()+Math.random()-1.5)*grain*.75;d[i]=Math.max(0,Math.min(255,d[i]+n));d[i+1]=Math.max(0,Math.min(255,d[i+1]+n));d[i+2]=Math.max(0,Math.min(255,d[i+2]+n))}}ctx.putImageData(im,0,0);return canvas}
function crc32(buf){let t=crc32.table;if(!t){t=crc32.table=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;t[n]=c>>>0}}let c=0xffffffff;for(let i=0;i<buf.length;i++)c=t[(c^buf[i])&255]^(c>>>8);return(c^0xffffffff)>>>0}
async function pngWithDPI(canvas,dpi){const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('No se pudo codificar el PNG')),'image/png'));const bytes=new Uint8Array(await blob.arrayBuffer()),ppm=Math.round(dpi/.0254),chunk=new Uint8Array(21),dv=new DataView(chunk.buffer);dv.setUint32(0,9);chunk.set([0x70,0x48,0x59,0x73],4);dv.setUint32(8,ppm);dv.setUint32(12,ppm);chunk[16]=1;dv.setUint32(17,crc32(chunk.subarray(4,17)));const at=33,out=new Uint8Array(bytes.length+21);out.set(bytes.subarray(0,at));out.set(chunk,at);out.set(bytes.subarray(at),at+21);return new Blob([out],{type:'image/png'})}
$('stop').onclick=()=>{cancel=true};$('go').onclick=async()=>{
 if(!srcImg){log('Primero selecciona una imagen.');return}
 const mode=$('mode').value,dpi=currentDpi(),cmW=parseFloat($('targetW').value),cmH=parseFloat($('targetH').value);
 if(!Number.isFinite(dpi)||dpi<72||dpi>1200){log('Introduce un PPI entre 72 y 1200.');return}
 if(!Number.isFinite(cmW)||cmW<=0||!Number.isFinite(cmH)||cmH<=0){log('Introduce un ancho y alto final válidos en centímetros.');return}
 const targetW=Math.max(1,Math.round(cmW/2.54*dpi)),targetH=Math.max(1,Math.round(cmH/2.54*dpi));
 const W=srcImg.naturalWidth,H=srcImg.naturalHeight;
 if(targetW>16384||targetH>16384||targetW*targetH>36000000){log('La medida final supera el límite recomendado para Android (16,384 px por lado y 36 megapíxeles). Reduce la medida o el PPI.');return}
 const sourceAlreadyEnough=targetW<=W&&targetH<=H;
 const needsAI=mode==='ai'&&!sourceAlreadyEnough;
 if(needsAI&&(targetW>16384||targetH>16384||targetW*targetH>36000000)){
   log('La salida solicitada supera el límite de procesamiento IA recomendado para Android. Reduce la medida final o los PPI.');
   return;
 }
 cancel=false;$('go').disabled=true;$('stop').disabled=false;$('dl').disabled=true;$('resultPane').innerHTML='<div class="placeholder">Procesando…</div>';progress(0);
 try{
   let canvas,method;
   if(sourceAlreadyEnough){
     log('La imagen original ya tiene píxeles suficientes para la medida solicitada. Se omite la IA y se ajusta directamente para ahorrar tiempo y memoria en Android.');
     await tick();canvas=srcImgToCanvas(srcImg);method='ajuste directo desde original';
   }else if(mode==='ai'){
     const s=await loadModel();
     canvas=await aiUpscaleToTarget(srcImg,s,parseInt($('tile').value,10),targetW,targetH);
     method='IA Real-ESRGAN x4 por bloques · resolución final automática';
   }else{
     log('Preparando ampliación clásica…');await tick();canvas=srcImgToCanvas(srcImg);method='interpolación clásica + ajuste a medida';
   }
   if(cancel)throw Error('Proceso cancelado');
   log('Ajustando a las dimensiones exactas de impresión…');await tick();
   canvas=resizeToPrintSize(canvas,targetW,targetH);
   canvas=finishTexture(canvas,parseInt($('sharp').value,10),parseInt($('grain').value,10));
   log('Generando PNG con metadatos de impresión…');await tick();
   resultBlob=await pngWithDPI(canvas,dpi);
   if(resultUrl)URL.revokeObjectURL(resultUrl);resultUrl=URL.createObjectURL(resultBlob);
   const im=new Image();im.src=resultUrl;await new Promise((res,rej)=>{im.onload=res;im.onerror=rej});
   $('resultPane').innerHTML='';$('resultPane').appendChild(im);
   $('stats').textContent=`Salida final: ${canvas.width} × ${canvas.height} px · ${dpi} PPI · ${cmW.toFixed(2)} × ${cmH.toFixed(2)} cm · ${method} · ${(resultBlob.size/1048576).toFixed(1)} MB`;
   $('dl').disabled=false;progress(1);log('Terminado. Comprueba al 100–200% los bordes, huecos y transparencias antes de imprimir.');
 }catch(e){log('Error: '+(e.message||e))}
 finally{$('go').disabled=false;$('stop').disabled=true}
};
async function blobToBase64(blob){return await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(reader.error||Error('No se pudo preparar el PNG'));reader.readAsDataURL(blob)})}
async function savePngOnAndroid(){
 if(!resultBlob)return;
 const fileName=(srcName||'diseno')+'_DTF_resolucion_final.png';
 try{
   const {Filesystem,Directory}=await import('@capacitor/filesystem');
   const {Share}=await import('@capacitor/share');
   const base64=await blobToBase64(resultBlob);
   const saved=await Filesystem.writeFile({path:fileName,data:base64,directory:Directory.Cache,recursive:true});
   await Share.share({title:'Guardar diseño DTF',text:'PNG final listo para impresión',files:[saved.uri],dialogTitle:'Guardar o compartir PNG'});
   log('PNG preparado. En el menú de Android elige Archivos/Files y después la carpeta Descargas para guardarlo.');
 }catch(e){
   if(window.Capacitor?.isNativePlatform?.()){
     log('No se pudo abrir Guardar/Compartir: '+(e.message||e));
   }else{
     const a=document.createElement('a');a.href=resultUrl;a.download=fileName;document.body.appendChild(a);a.click();a.remove();
     log('Descarga iniciada en el navegador.');
   }
 }
}
$('dl').onclick=savePngOnAndroid;
